const http = require('http');
const { spawn, execSync } = require('child_process');
const os = require('os');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');

// Securely load local .env without external dependencies
function loadEnv() {
    const envPath = path.join(__dirname, '.env');
    if (fs.existsSync(envPath)) {
        try {
            const content = fs.readFileSync(envPath, 'utf8');
            for (const line of content.split('\n')) {
                const trimmed = line.trim();
                if (!trimmed || trimmed.startsWith('#')) continue;
                const eqIdx = trimmed.indexOf('=');
                if (eqIdx > 0) {
                    const key = trimmed.substring(0, eqIdx).trim();
                    let val = trimmed.substring(eqIdx + 1).trim();
                    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
                        val = val.slice(1, -1);
                    }
                    if (!process.env[key]) {
                        process.env[key] = val;
                    }
                }
            }
        } catch (e) {
            console.error('[Security] Failed to read .env file:', e.message);
        }
    }
}
loadEnv();

const PORT = process.env.PORT || 3880;

// Security: Resolve ACCESS_PASSWORD strictly from private environment or .env
let ACCESS_PASSWORD = (process.env.LAP_PASSWORD || '').trim();
if (!ACCESS_PASSWORD) {
    const generated = crypto.randomBytes(12).toString('hex');
    const envPath = path.join(__dirname, '.env');
    try {
        fs.writeFileSync(envPath, `# K-Term Security Configuration\n# Keep this private - never commit to Git!\nLAP_PASSWORD=${generated}\nPORT=3880\n`, { mode: 0o600 });
        ACCESS_PASSWORD = generated;
        process.env.LAP_PASSWORD = generated;
        console.log('[Security] Auto-generated strong LAP_PASSWORD and saved to local .env (0600 mode)');
    } catch (e) {
        ACCESS_PASSWORD = generated;
        process.env.LAP_PASSWORD = generated;
    }
}

// IP & Brute Force Rate Limiting
const loginAttempts = new Map(); // ip -> { count, firstAttempt, lockedUntil }
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_MS = 15 * 60 * 1000; // 15 minute lockout
const WINDOW_MS = 10 * 60 * 1000;  // 10 minute attempt window

function getClientIp(req) {
    const forwarded = req.headers['x-forwarded-for'];
    if (forwarded) {
        return forwarded.split(',')[0].trim();
    }
    return req.socket.remoteAddress || 'unknown';
}

function checkLoginRateLimit(ip) {
    const record = loginAttempts.get(ip);
    if (!record) return { allowed: true };
    const now = Date.now();
    if (record.lockedUntil && now < record.lockedUntil) {
        const remainingMinutes = Math.ceil((record.lockedUntil - now) / 60000);
        return {
            allowed: false,
            error: `ආරක්ෂක හේතු මත මෙම IP ලිපිනය විනාඩි ${remainingMinutes}කට තාවකාලිකව අවහිර කර ඇත (Too many failed attempts).`
        };
    }
    if (now - record.firstAttempt > WINDOW_MS) {
        loginAttempts.delete(ip);
        return { allowed: true };
    }
    return { allowed: true };
}

function recordFailedLogin(ip) {
    const now = Date.now();
    const record = loginAttempts.get(ip) || { count: 0, firstAttempt: now, lockedUntil: null };
    record.count += 1;
    if (record.count >= MAX_FAILED_ATTEMPTS) {
        record.lockedUntil = now + LOCKOUT_MS;
        console.warn(`[SECURITY ALERT] IP ${ip} temporarily locked out after ${record.count} failed login attempts.`);
    }
    loginAttempts.set(ip, record);
}

function resetLoginRateLimit(ip) {
    loginAttempts.delete(ip);
}

// Constant-time password verification to prevent timing attacks
function verifyPassword(inputPassword, actualPassword) {
    if (typeof inputPassword !== 'string' || typeof actualPassword !== 'string') return false;
    if (!actualPassword || actualPassword.length === 0) return false;
    const inputHash = crypto.createHash('sha256').update(inputPassword).digest();
    const actualHash = crypto.createHash('sha256').update(actualPassword).digest();
    return crypto.timingSafeEqual(inputHash, actualHash);
}

// Upload directory for webcam captures
const uploadDir = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

// Hardened Multer storage for webcam and audio uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        const ext = path.extname(file.originalname || '.jpg').toLowerCase();
        const safeExt = ['.jpg', '.jpeg', '.png', '.wav'].includes(ext) ? ext : '.jpg';
        const randomName = 'snap-' + crypto.randomBytes(12).toString('hex') + safeExt;
        cb(null, randomName);
    }
});

const uploadWebcamMiddleware = multer({
    storage: storage,
    limits: { fileSize: 15 * 1024 * 1024 }, // 15MB limit
    fileFilter: function (req, file, cb) {
        const ext = path.extname(file.originalname || '').toLowerCase();
        const allowedExts = ['.jpg', '.jpeg', '.png', '.wav'];
        const allowedMimes = ['image/jpeg', 'image/png', 'audio/wav', 'audio/x-wav', 'application/octet-stream'];
        if (allowedExts.includes(ext) || allowedMimes.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error('Invalid file type: only JPG, PNG, and WAV files are allowed.'));
        }
    }
}).single('webcamPhoto');

// SSE clients for real-time webcam & dashboard updates
let sseClients = [];
let agentCommandQueue = [];

// Keep-alive heartbeat for SSE every 15s to prevent proxy timeouts
setInterval(() => {
    sseClients.forEach(client => {
        try {
            client.write(': heartbeat\n\n');
        } catch(e) {}
    });
}, 15000);

// Active auth sessions (persisted to disk across restarts)
const sessions = new Map();
const SESSIONS_FILE = '/tmp/lap_sessions.json';

function loadSessions() {
    try {
        if (fs.existsSync(SESSIONS_FILE)) {
            const data = JSON.parse(fs.readFileSync(SESSIONS_FILE, 'utf8'));
            for (const [k, v] of Object.entries(data)) {
                if (v > Date.now()) sessions.set(k, v);
            }
        }
    } catch(e) {}
}
loadSessions();

function saveSessions() {
    try {
        const obj = {};
        for (const [k, v] of sessions.entries()) obj[k] = v;
        fs.writeFileSync(SESSIONS_FILE, JSON.stringify(obj));
    } catch(e) {}
}

function generateToken() {
    const token = crypto.randomBytes(32).toString('hex');
    sessions.set(token, Date.now() + 24 * 60 * 60 * 1000);
    saveSessions();
    return token;
}

function isValidSession(token) {
    if (!token) return false;
    const expires = sessions.get(token);
    if (!expires) return false;
    if (Date.now() > expires) {
        sessions.delete(token);
        saveSessions();
        return false;
    }
    return true;
}

// Clean up expired sessions periodically
setInterval(() => {
    const now = Date.now();
    for (const [token, exp] of sessions.entries()) {
        if (now > exp) sessions.delete(token);
    }
}, 60 * 60 * 1000);

// Background Auto-Sync: Check GitHub every 60s as a fallback to Webhooks
setInterval(() => {
    try {
        execSync('git fetch origin main', { cwd: __dirname, stdio: 'ignore' });
        const statusOut = execSync('git status -uno', { cwd: __dirname, encoding: 'utf8' });
        if (statusOut.includes('Your branch is behind')) {
            console.log('[Auto-Sync] Remote changes detected! Pulling from GitHub...');
            const pullOut = execSync('git pull origin main', { cwd: __dirname, encoding: 'utf8' });
            console.log('[Auto-Sync] Pull result:\n' + pullOut);
            if (pullOut.includes('server.js')) {
                console.log('[Auto-Sync] server.js updated, self-restarting in 1s...');
                setTimeout(() => process.exit(0), 1000);
            }
        }
    } catch (e) {
        // Silently ignore transient network blips
    }
}, 60 * 1000);

// Laptop Agent State
let connectedAgent = null; // { hostname, user, os, cores, lastSeen }
let pendingCommands = [];  // [ { id, cmd, resolve, assigned, timer } ]

function isAgentOnline() {
    return connectedAgent && (Date.now() - connectedAgent.lastSeen < 7000);
}

function getSystemStats() {
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const memUsagePct = ((usedMem / totalMem) * 100).toFixed(1);

    const cpus = os.cpus();
    const cpuModel = cpus.length > 0 ? cpus[0].model : 'Unknown CPU';
    const cpuCores = cpus.length;

    let diskInfo = 'N/A';
    try {
        const dfOut = execSync("df -h / | awk 'NR==2 {print $2, $3, $4, $5}'", { encoding: 'utf8' }).trim();
        const parts = dfOut.split(/\s+/);
        if (parts.length >= 4) {
            diskInfo = { total: parts[0], used: parts[1], free: parts[2], pct: parts[3] };
        }
    } catch (e) {
        diskInfo = { total: '?', used: '?', free: '?', pct: '?' };
    }

    const uptimeSec = os.uptime();
    const days = Math.floor(uptimeSec / 86400);
    const hours = Math.floor((uptimeSec % 86400) / 3600);
    const minutes = Math.floor((uptimeSec % 3600) / 60);
    const uptimeStr = `${days}d ${hours}h ${minutes}m`;

    return {
        agent: isAgentOnline() ? { ...connectedAgent, online: true } : null,
        hostname: os.hostname(),
        platform: `${os.type()} ${os.release()} (${os.arch()})`,
        uptime: uptimeStr,
        cpu: {
            model: cpuModel,
            cores: cpuCores,
            load: os.loadavg().map(l => l.toFixed(2))
        },
        memory: {
            total: (totalMem / (1024 ** 3)).toFixed(2) + ' GB',
            used: (usedMem / (1024 ** 3)).toFixed(2) + ' GB',
            free: (freeMem / (1024 ** 3)).toFixed(2) + ' GB',
            percent: memUsagePct
        },
        disk: diskInfo,
        user: os.userInfo().username
    };
}

const server = http.createServer((req, res) => {
    const parsedUrl = new URL(req.url, `http://${req.headers.host}`);
    const pathname = parsedUrl.pathname;

    // CORS & Robust Security Headers
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Content-Security-Policy', "default-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://fonts.gstatic.com data: blob:; img-src 'self' data: blob:; media-src 'self' data: blob:; connect-src 'self' ws: wss:;");
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

    if (req.method === 'OPTIONS') {
        res.writeHead(200);
        return res.end();
    }

    // ==========================================
    // WEBCAM & SSE EVENT STREAM ENDPOINTS
    // ==========================================

    // SSE: Live Webcam & System Event Stream (Secured: requires valid session token)
    if (pathname === '/api/events') {
        const streamToken = parsedUrl.searchParams.get('token') || (req.headers['authorization'] || '').replace(/^Bearer\s+/i, '');
        if (!isValidSession(streamToken)) {
            res.writeHead(401, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ error: 'Unauthorized: Valid session token required for live stream.' }));
        }

        res.writeHead(200, {
            'Content-Type': 'text/event-stream',
            'Cache-Control': 'no-cache, no-transform',
            'Connection': 'keep-alive',
            'X-Accel-Buffering': 'no'
        });
        res.write(': connected\n\n');
        sseClients.push(res);
        req.on('close', () => {
            sseClients = sseClients.filter(client => client !== res);
        });
        return;
    }

    // Webcam Command Queue (POST /api/command) (Secured: requires valid session token)
    if (req.method === 'POST' && pathname === '/api/command') {
        const cmdToken = parsedUrl.searchParams.get('token') || (req.headers['authorization'] || '').replace(/^Bearer\s+/i, '');
        if (!isValidSession(cmdToken)) {
            res.writeHead(401, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ error: 'Unauthorized: Valid session token required to queue commands.' }));
        }

        let body = '';
        req.on('data', chunk => {
            body += chunk;
            if (body.length > 8192) req.destroy();
        });
        req.on('end', () => {
            try {
                const data = JSON.parse(body || '{}');
                const command = (data.command || '').toString().trim();
                if (command) {
                    agentCommandQueue.push(command);
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ success: true, message: "Command queued for agent", command }));
                } else {
                    res.writeHead(400, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ error: "No command provided" }));
                }
            } catch (err) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: "Invalid JSON format" }));
            }
        });
        return;
    }

    // Webcam Agent Polling (GET /api/poll)
    if (req.method === 'GET' && pathname === '/api/poll') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        if (agentCommandQueue.length > 0) {
            const cmd = agentCommandQueue.shift();
            res.end(JSON.stringify({ command: cmd }));
        } else {
            res.end(JSON.stringify({ command: null }));
        }
        return;
    }

    // Webcam Photo Upload Endpoint (POST /api/upload-webcam)
    if (req.method === 'POST' && pathname === '/api/upload-webcam') {
        uploadWebcamMiddleware(req, res, (err) => {
            if (err) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                return res.end(JSON.stringify({ success: false, error: err.message }));
            }
            if (!req.file) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                return res.end(JSON.stringify({ success: false, error: 'No webcam photo uploaded.' }));
            }

            const imageUrl = `/uploads/${req.file.filename}`;

            // Notify all connected web dashboards live via SSE
            sseClients.forEach(client => {
                try {
                    client.write(`data: ${JSON.stringify({ type: 'webcam_update', url: imageUrl })}\n\n`);
                } catch(e) {}
            });

            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: true, imageUrl }));
        });
        return;
    }

    // ==========================================
    // AGENT ENDPOINTS (Called by K-Term Agent)
    // ==========================================

    // Agent Poll Endpoint: Heartbeat & Command Fetching
    if (req.method === 'POST' && pathname === '/api/agent/poll') {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            try {
                const data = JSON.parse(body || '{}');
                connectedAgent = {
                    hostname: data.hostname || 'Physical Laptop',
                    user: data.user || 'User',
                    os: data.os || 'Windows',
                    cores: data.cores || '1',
                    cpuModel: data.cpuModel || '',
                    ramTotal: data.ramTotal || '',
                    ramUsed: data.ramUsed || '',
                    ramPercent: data.ramPercent || '',
                    diskTotal: data.diskTotal || '',
                    diskFree: data.diskFree || '',
                    diskPercent: data.diskPercent || '',
                    lastSeen: Date.now()
                };

                // Check if any command is queued for execution
                const nextCmd = pendingCommands.find(c => !c.assigned);
                if (nextCmd) {
                    nextCmd.assigned = true;
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    return res.end(JSON.stringify({ id: nextCmd.id, cmd: nextCmd.cmd }));
                }

                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ status: 'idle' }));
            } catch (err) {
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ status: 'idle' }));
            }
        });
        return;
    }

    // Agent Result Endpoint: Laptop returns stdout/stderr
    if (req.method === 'POST' && pathname === '/api/agent/result') {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            try {
                const data = JSON.parse(body || '{}');
                if (data.id) {
                    const idx = pendingCommands.findIndex(c => c.id === data.id);
                    if (idx !== -1) {
                        const item = pendingCommands[idx];
                        clearTimeout(item.timer);
                        pendingCommands.splice(idx, 1);
                        item.resolve(data.output || '');
                    }
                }
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true }));
            } catch (err) {
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: false }));
            }
        });
        return;
    }

    // ==========================================
    // GITHUB AUTO-DEPLOY & WEBHOOK ENDPOINTS
    // ==========================================

    // GitHub Webhook Endpoint: Auto-pulls within seconds of any commit on GitHub
    if (pathname === '/api/webhook/github') {
        if (req.method === 'GET') {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ status: 'ok', message: 'GitHub Webhook endpoint active' }));
        }

        if (req.method === 'POST') {
            let body = '';
            req.on('data', chunk => body += chunk);
            req.on('end', () => {
                const event = req.headers['x-github-event'] || 'push';
                if (event === 'ping') {
                    console.log('[GitHub Webhook] Ping received from GitHub! Webhook is verified.');
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    return res.end(JSON.stringify({ success: true, message: 'Pong! Webhook verified and active.' }));
                }

                console.log(`[GitHub Webhook] Event "${event}" received! Auto-pulling from GitHub main...`);
                try {
                    const pullOut = execSync('git pull origin main', { cwd: __dirname, encoding: 'utf8' });
                    console.log('[GitHub Webhook] Pulled changes:\n' + pullOut);
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ success: true, output: pullOut }));

                    if (pullOut.includes('server.js')) {
                        console.log('[GitHub Webhook] server.js updated, self-restarting in 1s...');
                        setTimeout(() => process.exit(0), 1000);
                    }
                } catch (err) {
                    console.error('[GitHub Webhook Error]:', err.message);
                    res.writeHead(500, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ success: false, error: err.message }));
                }
            });
            return;
        }
    }

    // Manual GitHub Sync: Triggered from web console
    if (req.method === 'POST' && pathname === '/api/git/sync') {
        const authHeader = req.headers['authorization'] || '';
        const token = authHeader.replace(/^Bearer\s+/i, '') || parsedUrl.searchParams.get('token');
        if (!isValidSession(token)) {
            res.writeHead(401, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ error: 'Unauthorized' }));
        }
        try {
            const pullOut = execSync('git pull origin main', { cwd: __dirname, encoding: 'utf8' });
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: true, output: pullOut }));
            if (pullOut.includes('server.js')) {
                setTimeout(() => process.exit(0), 1000);
            }
        } catch (err) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: false, error: err.message }));
        }
        return;
    }

    // API: Login (Protected with IP Rate Limiting & Timing-Safe Hash Verification)
    if (req.method === 'POST' && pathname === '/api/login') {
        const clientIp = getClientIp(req);
        const rateCheck = checkLoginRateLimit(clientIp);
        if (!rateCheck.allowed) {
            res.writeHead(429, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ success: false, error: rateCheck.error }));
        }

        let body = '';
        req.on('data', chunk => {
            body += chunk;
            if (body.length > 4096) req.destroy();
        });
        req.on('end', () => {
            try {
                const data = JSON.parse(body || '{}');
                const userPass = (data.password || '').toString();
                if (verifyPassword(userPass, ACCESS_PASSWORD)) {
                    resetLoginRateLimit(clientIp);
                    const token = generateToken();
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ success: true, token }));
                } else {
                    recordFailedLogin(clientIp);
                    res.writeHead(401, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ success: false, error: 'වැරදි Password එකක්! කරුණාකර නැවත උත්සාහ කරන්න.' }));
                }
            } catch (err) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: false, error: 'Invalid JSON request' }));
            }
        });
        return;
    }

    // Auth Middleware for protected endpoints
    const authHeader = req.headers['authorization'] || '';
    const token = authHeader.replace(/^Bearer\s+/i, '') || parsedUrl.searchParams.get('token');

    // API: System Stats
    if (pathname === '/api/stats') {
        if (!isValidSession(token)) {
            res.writeHead(401, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ error: 'Unauthorized' }));
        }
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify(getSystemStats()));
    }

    // API: Execute command with live SSE streaming
    if (pathname === '/api/exec') {
        if (!isValidSession(token)) {
            res.writeHead(401, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ error: 'Unauthorized' }));
        }

        const cmd = parsedUrl.searchParams.get('cmd');
        if (!cmd) {
            res.writeHead(400, { 'Content-Type': 'text/plain' });
            return res.end('No command provided');
        }

        // Set up SSE for streaming stdout & stderr live
        res.writeHead(200, {
            'Content-Type': 'text/event-stream',
            'Cache-Control': 'no-cache, no-transform',
            'Connection': 'keep-alive',
            'X-Accel-Buffering': 'no'
        });

        const sendEvent = (event, data) => {
            res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
        };

        // IF PHYSICAL LAPTOP AGENT IS ONLINE -> EXECUTE ON LAPTOP!
        if (isAgentOnline()) {
            sendEvent('stdout', `[⚡ EXECUTING ON PHYSICAL LAPTOP (${connectedAgent.hostname}) via K-Term Agent]\n`);
            
            const cmdId = crypto.randomBytes(8).toString('hex');
            const timer = setTimeout(() => {
                const idx = pendingCommands.findIndex(c => c.id === cmdId);
                if (idx !== -1) {
                    pendingCommands.splice(idx, 1);
                    sendEvent('stderr', '\n[ERROR] Laptop command timed out after 30 seconds.\n');
                    sendEvent('exit', { code: 1 });
                    res.end();
                }
            }, 30000);

            pendingCommands.push({
                id: cmdId,
                cmd: cmd,
                assigned: false,
                timer: timer,
                resolve: (output) => {
                    sendEvent('stdout', output + '\n');
                    sendEvent('exit', { code: 0 });
                    res.end();
                }
            });

            req.on('close', () => {
                const idx = pendingCommands.findIndex(c => c.id === cmdId);
                if (idx !== -1) {
                    clearTimeout(pendingCommands[idx].timer);
                    pendingCommands.splice(idx, 1);
                }
            });
            return;
        }

        // FALLBACK: NO LAPTOP AGENT CONNECTED -> EXECUTE ON VPS
        sendEvent('stdout', `[Notice: Laptop Agent not running. Executing on Cloud VPS (${os.hostname()})]\n[Tip: Run K-Term Agent on your laptop to execute directly on your physical laptop!]\n\n`);

        const currentDir = process.env.HOME || '/home/dinujaya';
        const child = spawn(cmd, {
            shell: true,
            cwd: currentDir,
            env: { ...process.env, TERM: 'xterm-256color', PAGER: 'cat' }
        });

        child.stdout.on('data', chunk => {
            sendEvent('stdout', chunk.toString('utf8'));
        });

        child.stderr.on('data', chunk => {
            sendEvent('stderr', chunk.toString('utf8'));
        });

        child.on('error', err => {
            sendEvent('stderr', `Execution Error: ${err.message}\n`);
            sendEvent('exit', { code: 1 });
            res.end();
        });

        child.on('close', code => {
            sendEvent('exit', { code: code ?? 0 });
            res.end();
        });

        req.on('close', () => {
            if (!child.killed) child.kill();
        });

        return;
    }

    // Serve Static UI (index.html)
    if (pathname === '/' || pathname === '/index.html') {
        const indexPath = path.join(__dirname, 'public', 'index.html');
        fs.readFile(indexPath, 'utf8', (err, html) => {
            if (err) {
                res.writeHead(500, { 'Content-Type': 'text/plain' });
                return res.end('Error loading dashboard: ' + err.message);
            }
            res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
            res.end(html);
        });
        return;
    }

    // Serve Webcam UI (webcam.html)
    if (pathname === '/webcam' || pathname === '/webcam.html') {
        const webcamPath = path.join(__dirname, 'public', 'webcam.html');
        if (fs.existsSync(webcamPath)) {
            res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
            fs.createReadStream(webcamPath).pipe(res);
            return;
        }
    }

    // Serve Uploaded Media (/uploads/snap-xxx.jpg)
    if (pathname.startsWith('/uploads/')) {
        const imgName = path.basename(pathname);
        const imgPath = path.join(uploadDir, imgName);
        const resolvedPath = path.resolve(imgPath);
        const resolvedUpload = path.resolve(uploadDir);

        if (!resolvedPath.startsWith(resolvedUpload + path.sep)) {
            res.writeHead(403, { 'Content-Type': 'text/plain' });
            return res.end('Forbidden: Access outside uploads directory');
        }

        if (fs.existsSync(resolvedPath) && fs.statSync(resolvedPath).isFile()) {
            const ext = path.extname(resolvedPath).toLowerCase();
            let mime = 'application/octet-stream';
            if (ext === '.png') mime = 'image/png';
            else if (ext === '.jpg' || ext === '.jpeg') mime = 'image/jpeg';
            else if (ext === '.wav') mime = 'audio/wav';

            res.writeHead(200, {
                'Content-Type': mime,
                'Cache-Control': 'public, max-age=86400'
            });
            fs.createReadStream(resolvedPath).pipe(res);
            return;
        }
    }

    // Serve Downloads / Static Files (e.g. agent.ps1, webcam-agent.ps1, executables)
    const requestedFile = path.basename(pathname);
    const staticFilePath = path.join(__dirname, 'public', requestedFile);
    const resolvedStaticPath = path.resolve(staticFilePath);
    const resolvedPublicDir = path.resolve(__dirname, 'public');

    // Strict path traversal boundary verification
    if (!resolvedStaticPath.startsWith(resolvedPublicDir + path.sep) && resolvedStaticPath !== resolvedPublicDir) {
        res.writeHead(403, { 'Content-Type': 'text/plain' });
        return res.end('Forbidden: Access outside public directory');
    }

    if (fs.existsSync(resolvedStaticPath) && fs.statSync(resolvedStaticPath).isFile()) {
        const ext = path.extname(resolvedStaticPath).toLowerCase();
        let mime = 'application/octet-stream';
        if (ext === '.html') mime = 'text/html; charset=utf-8';
        else if (ext === '.js') mime = 'application/javascript';
        else if (ext === '.css') mime = 'text/css';
        else if (ext === '.json') mime = 'application/json';
        else if (ext === '.png') mime = 'image/png';
        else if (ext === '.jpg' || ext === '.jpeg') mime = 'image/jpeg';
        else if (ext === '.wav') mime = 'audio/wav';
        else if (ext === '.mp3') mime = 'audio/mpeg';
        else if (ext === '.ps1') mime = 'text/plain; charset=utf-8';
        else if (ext === '.bat') mime = 'text/plain; charset=utf-8';

        res.writeHead(200, {
            'Content-Type': mime,
            'Content-Disposition': (ext === '.exe' || ext === '.zip') ? `attachment; filename="${requestedFile}"` : 'inline',
            'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=3600'
        });
        fs.createReadStream(resolvedStaticPath).pipe(res);
        return;
    }

    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not Found');
});

server.listen(PORT, '127.0.0.1', () => {
    console.log(`[K-Term Lap Terminal] running on http://127.0.0.1:${PORT}`);
    console.log(`[K-Term Security] Password authentication active (configured via .env / environment).`);
});
